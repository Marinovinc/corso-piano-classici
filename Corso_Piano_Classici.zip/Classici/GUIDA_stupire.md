# Classici famosi al pianoforte — guida (per stupire gli amici)

`[sessione 3c88c123, 04/10/2026]` — corso della serie. Arrangiamenti **semplificati** a due mani
(melodia a destra, accordi a sinistra) di classici celebri di **pubblico dominio**, per Synthesia.

Sono i brani che, appena li suoni, **tutti riconoscono**. Qui in versione ridotta e alla portata di
un principiante: non la versione da concerto, ma il tema principale, quello che fa dire "wow".

**Regola d'oro: prima la mano sinistra, da sola, lenta.** Poi la melodia.

---

## I brani (4)

| # | File | Note |
|---|---|---|
| 1 | `1_Fur_Elise` | Beethoven &mdash; il tema piu' famoso (la minore) |
| 2 | `2_Minuetto_in_Sol` | Petzold/Bach &mdash; il Minuetto del Quaderno di Anna Magdalena |
| 3 | `3_Inno_alla_Gioia` | Beethoven &mdash; dalla 9ª Sinfonia, facilissimo |
| 4 | `4_Quinta_di_Beethoven` | il motivo piu' celebre della storia: "ta-ta-ta-taaa" |

Ogni brano ha il suo **MP3**. Comincia dall'**Inno alla Gioia** (il piu' facile), poi Für Elise.

---

## Onesta' sui file

Trascrizioni semplificate di opere di pubblico dominio (Beethoven, Petzold), melodie prese da fonti di
notazione; arrangiamento nostro, mani separate. Sono **versioni facili** del tema principale: servono
a suonare subito qualcosa di riconoscibile e d'effetto. Per le versioni integrali servira', un giorno,
molto piu' studio &mdash; ma per stupire gli amici questi bastano e avanzano. Un tasto alla volta.
